const app = Vue.createApp({
    data() {
        return {
            eventObj: { eventid: '', eventname: '', category: 'Business', durationhour: ''},
            searchId: '',
            searchName: '',
            searchDuration: '',
            events: [
                {eventid: 'EVT10001', eventname: 'Tech Innovations Conference', category: 'Technology', durationhour: 8},
                {eventid: 'EVT10002', eventname: 'Startup Pitch Day', category: 'Business', durationhour: 6},
                {eventid: 'EVT10003', eventname: 'AI & Machine Learning Summit', category: 'Technology', durationhour: 10},
                {eventid: 'EVT10004', eventname: 'Cybersecurity Workshop', category: 'Technology', durationhour: 4},
                {eventid: 'EVT10005', eventname: 'Digital Marketing Bootcamp', category: 'Marketing', durationhour: 6},
                {eventid: 'EVT10006', eventname: 'Blockchain and Cryptocurrency', category: 'Finance', durationhour: 5},
                {eventid: 'EVT10007', eventname: 'Entrepreneurship Forum', category: 'Business', durationhour: 7},
                {eventid: 'EVT10008', eventname: 'Data Science Hackathon', category: 'Technology', durationhour: 12},
                {eventid: 'EVT10009', eventname: 'Leadership and Management Summit', category: 'Business', durationhour: 9},
                {eventid: 'EVT10010', eventname: 'E-commerce Strategies', category: 'Marketing', durationhour: 6},
                {eventid: 'EVT10011', eventname: 'AI for Business', category: 'Business', durationhour: 8},
                {eventid: 'EVT10012', eventname: 'IoT & Smart Devices Expo', category: 'Technology', durationhour: 7},
                {eventid: 'EVT10013', eventname: 'Brand Strategy and Growth', category: 'Marketing', durationhour: 5},
                {eventid: 'EVT10014', eventname: 'Investment and Wealth Management', category: 'Finance', durationhour: 6},
                {eventid: 'EVT10015', eventname: 'Financial Technology (FinTech) Summit', category: 'Finance', durationhour: 8},
                {eventid: 'EVT10016', eventname: 'AI Ethics and Regulations', category: 'Technology', durationhour: 4},
                {eventid: 'EVT10017', eventname: 'Business Analytics Workshop', category: 'Business', durationhour: 6},
                {eventid: 'EVT10018', eventname: 'SEO and Content Marketing', category: 'Marketing', durationhour: 7},
                {eventid: 'EVT10019', eventname: 'Cryptocurrency Investment Strategies', category: 'Finance', durationhour: 9},
                {eventid: 'EVT10020', eventname: 'Social Media Marketing Trends', category: 'Marketing', durationhour: 5}
            ],

            form: { username:'', password:'', confirm_pass:'', selectevent:'' }
        }
    },
    computed: {
        filterMarks() {
            return this.events.filter(
                e => e.eventid.toLowerCase().includes(this.searchId.toLowerCase()) &&
                e.eventname.toLowerCase().includes(this.searchName.toLowerCase()) &&
                (this.searchDuration === '' || e.durationhour.toString().includes(this.searchDuration)) &&
                (this.eventObj.category === 'All' || !this.eventObj.category || e.category === this.eventObj.category)
            );
        },

        notMatchPass() {
            return (
                this.form.confirm_pass && this.form.password !== this.form.confirm_pass
            );
        }

        
    },

    watch: {
        'eventObj.category'() {
            this.form.selectevent = '';
        }
    },

    methods: {
        handleSubmit() {
            if (!this.notMatchPass) {
                // i have to ask AI to help me this part because idk how to submit form in vuejs
                const form = document.createElement('form');
                form.action = 'https://mercury.swin.edu.au/it000000/formtest.php';
                form.method = 'post';

                form.innerHTML = `
                    <input name="name" value="${this.form.username}">
                    <input name="password" value="${this.form.password}">
                    <input name="confirm_pass" value="${this.form.confirm_pass}">
                    <input name="category" value="${this.eventObj.category}">
                    <input name="event" value="${this.form.selectevent}">
                `;
                document.body.appendChild(form);
                form.submit();
            }

        }
    },
});
app.mount('body');