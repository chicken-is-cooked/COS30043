Vue.createApp(window.App).use(window.router).mount('#app');
