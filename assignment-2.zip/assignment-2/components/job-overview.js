window.JobOverview = {
    template: '#overview-tpl' 
};

//i used to use const w export like the suggestion vid but it didnt work so i changed to window, i think it
//have a higher access priority
